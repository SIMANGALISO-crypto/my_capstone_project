from django.http import HttpResponse

def home(request):
    """Returns the home page response."""
    return HttpResponse("Hello from Capstone Project")