# Capstone Django Project

## Running with Virtualenv

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python manage.py runserver
```

## Running with Docker

```bash
docker build -t capstone .
docker run -p 8000:8000 capstone
```

## Notes

- Create a `.env` file for secrets and environment variables.